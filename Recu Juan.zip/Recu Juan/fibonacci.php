<?php
$N=7;


for ($i=0; $i < $cont ; $i++) {
$N= $cont - $i;
echo "$cont";
}

 ?>
