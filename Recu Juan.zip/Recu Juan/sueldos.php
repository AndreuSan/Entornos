<?php

$categoría=1;
$hora=10;
$hijos=2;

if ($categoría == 1) {
 $sueldo = $hora*17 + $hijos*15;
  echo "$sueldo";
}elseif ($categoría == 2) {
  $sueldo = $hora*14 + $hijos*15;
  echo "$sueldo";
}else {
  $sueldo = $hora*11  + $hijos*15;
  echo "$sueldo";
}

 ?>
