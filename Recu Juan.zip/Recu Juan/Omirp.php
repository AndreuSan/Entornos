<?php

$num=2;

  if ( $num%2 == 0){
    echo "No es primo por lo que no es Omirp";
  }else{
    echo"Es primo por lo que podría ser Omirp";
    }

 ?>
